package Stepdefination;

import org.testng.annotations.Test;

public class Vrunner {
  @Test
  public void f() {
  }
}
