package vExecution;

import org.junit.Test;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import junit.framework.Assert;

public class vGetmethod {
	@Given("The Swagger API URI for Get Method")
	public void the_swagger_api_uri_for_get_method() {
		Response res=RestAssured.get("https://petstore.swagger.io/v2/user/vinay");

	}

	@SuppressWarnings("deprecation")
	@Then("The Response is returned as to be")
	public void the_response_is_returned_as_to_be() {
		Response res=RestAssured.get("https://petstore.swagger.io/v2/user/vinay");
		System.out.println("Status code "+res.getStatusCode());
		int status_code=res.statusCode();
		Assert.assertEquals(status_code, 200);
	  RestAssured.given()
      .when().get("https://petstore.swagger.io/v2/user/vinay")
      .then().log().all().statusCode(200);

	}


}
