package vExecution;
import java.util.HashMap;
import java.util.Map;
import com.google.gson.Gson;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import junit.framework.Assert;
public class vpost {
	@Given("The Swagger API URI for post Method")
	public void the_swagger_api_uri_for_post_method() {
		Map<String ,Object> vuser= new HashMap<String, Object>();
	      vuser.put("username", "vinay");

	      System.out.println(vuser);
	      String payload = new Gson().toJson(vuser);
	      RestAssured.given().header("Content-Type", "application/json")
	                         .contentType(ContentType.JSON).body(payload)
	                         .when().post("https://petstore.swagger.io/v2/user")
	                         .then().statusCode(200).log().all();

	}

	@SuppressWarnings("deprecation")
	@Then("The Response is returned as to be {int}")
	public void the_response_is_returned_as_to_be(Integer int1) {
		Response res=RestAssured.get("https://petstore.swagger.io/v2/user");
		System.out.println("Status code "+res.getStatusCode());
		int status_code=res.statusCode();
//		Assert.assertEquals(status_code, 200);
//	  RestAssured.given()
//      .when().get("https://petstore.swagger.io/v2/user")
//      .then().log().all().statusCode(200);


	}

}
