package vExecution;


import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

public class vdelete {


    @Test
    public void deleteMethodWithBDDApproach() {
        String requestusername = "vinay";
        RestAssured.given() 
                .baseUri("https://petstore.swagger.io/v2/user/vinay")
                .pathParam("username", requestusername)
                .when() 
                .delete("user/{username}")
                .then() 
                .statusCode(200);
    }
}