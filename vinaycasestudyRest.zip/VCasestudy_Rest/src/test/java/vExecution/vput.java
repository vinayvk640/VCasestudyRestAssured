package vExecution;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;


public class vput {

    public static Map<String, String> map = new HashMap<String, String>();

    @BeforeTest
    public void putdata(){
        map.put("username", "vinay");          
        Response res=RestAssured.put("https://petstore.swagger.io/v2/user/vinay");
    }

    @Test
    public void testPUT(){
        given()
        .contentType("application/json")
        .body(map)
        .when()
        .put("/vinay")
        .then()
        .statusCode(200)
        .and()
;       
    }
 }
